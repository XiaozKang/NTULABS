#ifndef ANIMAL_H
#define ANIMAL_H

#include <iostream>
#include <string>



class Animal {
public:
    Animal();

    virtual ~Animal();
    virtual void speak() const=0;
    virtual void move() const=0;
    virtual void eat() const=0;

private:
    std::string _name;

};

class Mammal : public Animal {
public:
    Mammal();

    ~Mammal() override;
    void speak() const;
    void move() const;
    void eat() const;
};

#endif // ANIMAL_H
