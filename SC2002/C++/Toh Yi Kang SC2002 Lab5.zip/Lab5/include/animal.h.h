#ifndef ANIMAL_H_H
#define ANIMAL_H_H


class animal.h
{
    public:
        animal.h();
        virtual ~animal.h();

    protected:

    private:
};

#endif // ANIMAL_H_H
