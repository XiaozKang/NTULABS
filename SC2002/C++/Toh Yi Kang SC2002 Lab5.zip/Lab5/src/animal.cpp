#include "animal.h"
#include "string"
using namespace std ;

Animal::Animal() : _name("unknown") {
    cout << "constructing Animal object " << endl;
}



Animal::~Animal() {
    cout << "destructing Animal object " << _name << endl;
}

void Animal::speak() const {
    cout << "Animal speaks " << endl;
}

void Animal::move() const {
    cout << "Animal moves " <<endl;
}

void Animal::eat() const {
    cout << "Animal eats " <<endl;
}

Mammal::Mammal() : Animal() {
    // ...
}



Mammal::~Mammal() {
    cout << "destructing Mammal object " << endl;
}

void Mammal::speak() const {
    cout << "Mammal speaks" << endl;
}

void Mammal::move() const {
    cout << "Mammal move" <<endl;
}

void Mammal::eat() const {
    cout << "Mammal eat" <<endl;
}
