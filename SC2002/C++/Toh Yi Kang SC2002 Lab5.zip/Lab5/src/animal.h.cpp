#include "animal.h.h"

animal.h::animal.h()
{
    //ctor
}

animal.h::~animal.h()
{
    //dtor
}
